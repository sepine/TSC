#!/usr/bin/env python3
import collections
import os
import sys
import pickle
import shlex
import random
import numpy as np
import pandas as pd
from itertools import permutations, combinations
from sklearn.preprocessing import scale
from sklearn.metrics import pairwise_distances, roc_auc_score
from typing import Iterable, Sequence
from collections import defaultdict

from classifiers import effort_aware, get_loc_data, positive_first, get_metrics
from merge import new_path
from modeling import evaluate, save, sklearn_classifier
from weka_wrapper import JVM, WekaDataset, weka_classifier

weka_classes_codep = [
    'bayes.BayesNet',
    'functions.Logistic',
    'functions.MultilayerPerceptron',
    'functions.RBFNetwork',
    'rules.DecisionTable',
    'trees.ADTree',
]

weka_classes_asci = [
    'bayes.NaiveBayes',
    'functions.Logistic',
    'functions.MultilayerPerceptron',
    'trees.J48',
    'functions.RBFNetwork',
]

weka_classes_div = [
    'bayes.NaiveBayes -K',
    'bayes.NaiveBayes -D',
    'lazy.IBk -K 3',
    'lazy.IBk -K 5',
    'lazy.IBk -K 7',
    'functions.SMO -C 1',
    'functions.SMO -C 10',
    'functions.SMO -C 25',
    'functions.SMO -C 50',
    'trees.J48 -C 0.25',
    'trees.J48 -C 0.20',
    'trees.J48 -C 0.15',
    'trees.J48 -C 0.10',
    'trees.J48 -C 0.05',
]


def base_classifiers(train: WekaDataset, cls_names: Iterable) -> Iterable:
    for i in cls_names:
        print(i)
        cls_name, *options = shlex.split(i)
        cls = weka.classifiers.Classifier('weka.classifiers.' + cls_name)
        cls.build_classifier(train.weka_XYu)
        yield cls


def codep_ensemble(train: WekaDataset, test: WekaDataset, classes: Sequence):
    train.Xu, test.Xu = [], []
    for dataset in train, test:
        for cls in classes:
            proba = cls.distributions_for_instances(dataset.weka_XYu)[:, 1]
            dataset.Xu.append(proba)
        dataset.Xu = np.array(dataset.Xu).T
    c = sklearn_classifier('linear_model.LogisticRegression')
    # test.Yp, proba = c(train, test)
    test.Yp = c(train, test)


def codep(train: WekaDataset, test: WekaDataset):
    classifiers = list(base_classifiers(train, weka_classes_codep))
    codep_ensemble(train, test, classifiers)


def max_diversity(train: WekaDataset, test: WekaDataset):
    classifiers = list(base_classifiers(train, weka_classes_div))
    train.Yp = [
        [cls.classify_instance(i) for i in train.weka_XYu]
        for cls in classifiers
    ]
    div = pairwise_distances(train.Yp, metric='manhattan')
    max_div, max_div_subset = max(
        (sum(div[x][y] for x, y in combinations(subset, 2)), subset)
        for subset in combinations(range(len(train.Yp)), 3)
    )
    print([weka_classes_div[i] for i in max_div_subset])
    codep_ensemble(train, test, [classifiers[i] for i in max_div_subset])


def asci(train: WekaDataset, test: WekaDataset):
    classifiers = list(base_classifiers(train, weka_classes_asci))
    F = [0] * len(classifiers)

    # get all correct classifiers for each instance in the training set
    correct_cls_no = [[] for i in train.Yu]
    for cls_no, cls in enumerate(classifiers):
        train.Yp = [cls.classify_instance(i) for i in train.weka_XYu]
        F[cls_no] = evaluate(train.Yu, train.Yp, None, None)['F1']
        for i, (u, p) in enumerate(zip(train.Yu, train.Yp)):
            if u == p:
                correct_cls_no[i].append(cls_no)

    # select a single classifier for each instance in the training set
    bug_label, train.Yu = train.Yu, np.empty_like(train.Yu)
    for i, lst in enumerate(correct_cls_no):
        if len(lst) == 1:
            train.Yu[i] = lst[0]
        else:
            max_F = max_F_cls_no = 0
            for cls_no in lst:
                if max_F < F[cls_no]:
                    max_F = F[cls_no]
                    max_F_cls_no = cls_no
            train.Yu[i] = max_F_cls_no

    # predict the best classifier for each instance in the testing set
    c = sklearn_classifier('tree.DecisionTreeClassifier')
    # test.Yp, proba = c(train, test)
    test.Yp = c(train, test)
    train.Yu = bug_label
    for x, i in enumerate(test.weka_XYu):
        # TODO
        cls_no = test.Yp[x].astype('int')
        cls = classifiers[cls_no]
        test.Yp[x] = cls.classify_instance(i)


def max_voting(train: WekaDataset, test: WekaDataset):
    classifiers = list(base_classifiers(train, weka_classes_codep))
    proba = [
        cls.distributions_for_instances(test.weka_XYu)[:, 1]
        for cls in classifiers
    ]
    test.Yp = np.array(proba).max(axis=0)


def average_voting(train: WekaDataset, test: WekaDataset):
    classifiers = list(base_classifiers(train, weka_classes_codep))
    proba = [
        cls.distributions_for_instances(test.weka_XYu)[:, 1]
        for cls in classifiers
    ]
    test.Yp = np.array(proba).mean(axis=0)


def bagging_j48(train: WekaDataset, test: WekaDataset):
    c = weka_classifier('meta.Bagging', '-W weka.classifiers.trees.J48')
    test.Yp = c(train, test)
    # return c(train, test)


def prepare_dataset(path: str, tmp='./tmp.csv') -> WekaDataset:
    df = pd.read_excel(path)
    df.columns = list(df.columns[:-1]) + ['bug']  # rename the bug class column
    df.loc[:, 'loc'] = df.iloc[:, 0]  # copy LOC to the last column
    df.iloc[:, :-2] = scale(df.iloc[:, :-2])
    df.to_csv(tmp, index=False)
    dataset = WekaDataset(tmp)
    dataset.path = new_path(path)
    return dataset


def data_normalization(datas):
    datas = (datas - np.mean(datas, axis=0, keepdims=True)) / (np.std(datas, axis=0, keepdims=True) + 1e-6)
    return datas


def data_wrapper(trains, labels, path, columns, flag=False, tmp='/tmp.csv') -> WekaDataset:
    target_label = np.reshape(labels, newshape=(len(labels), 1))

    if flag:
        trains = data_normalization(trains)

    target_datas = np.hstack((trains, target_label))
    df = pd.DataFrame(target_datas, columns=columns)
    df["loc"] = df["ld"] + df["la"]
    df.to_csv(tmp, index=False)
    dataset = WekaDataset(tmp)
    dataset.path = new_path(path)
    return dataset


def shuffle_data(datas, labels):
    num = len(datas)
    # 将datas表格数据随机打乱
    ids = random.sample(list(range(num)), num)
    return datas[ids], labels[ids]


# 根据split比例将datas数据集切分成训练集和测试集。split=0.1？？
def split_data(datas, labels, split):
    label2datas = defaultdict(list)
    for data, label in zip(datas, labels):
        label2datas[label].append(data)
    train_datas = []
    train_labels = []
    test_datas = []
    test_labels = []
    for k, values in label2datas.items():
        num = len(values)
        sep = int(num * split) + 1

        ids = random.sample(list(range(num)), num)
        for i in range(sep):
            train_datas.append(values[ids[i]])
            train_labels.append(k)
        for i in range(sep, num):
            test_datas.append(values[ids[i]])
            test_labels.append(k)
    train_datas = np.array(train_datas)
    train_labels = np.array(train_labels)
    test_datas = np.array(test_datas)
    test_labels = np.array(test_labels)
    return (train_datas, train_labels), (test_datas, test_labels)


def read_data(train_path, test_path, test_split=0.1, re_sample=True):
    train_name = os.path.split(train_path)[-1].split(".")[0]
    test_name = os.path.split(test_path)[-1].split(".")[0]
    # 将训练数据集和测试数据集的文件名整合成新的文件
    dump_path = "datas/temps/%s_%s.pkl" % (train_name, test_name)
    # 如果存在整理好的文件，直接读取，节省时间
    if os.path.exists(dump_path) and re_sample is False:
        return pickle.load(open(dump_path, "rb"))
    else:
        # 读取excel表格第一行数据
        train = pd.read_excel(train_path, header=0)
        # 消除NAN
        train.fillna(value=0, inplace=True)
        # iloc(): 读取固定列的数据
        columns = list(train.columns)
        train_datas = train.iloc[:, :-1].values
        train_datas = data_normalization(train_datas)
        train_labels = train.iloc[:, -1].values
        # 随机打乱训练数据和标签数据
        train_datas, train_labels = shuffle_data(train_datas, train_labels)

        test = pd.read_excel(test_path, header=0)
        test.fillna(value=0, inplace=True)
        test_datas = test.iloc[:, :-1].values
        (target_train_datas, target_train_labels), (target_test_datas, target_test_labels) = split_data(test_datas, test.iloc[:, -1].values, split=test_split)
        # 将整理好的数据保存至dump_path文件中，方便下次读取
        pickle.dump(
            [train_datas, train_labels, target_train_datas, target_train_labels, target_test_datas, target_test_labels, columns],
            open(dump_path, "wb"))

        return train_datas, train_labels, target_train_datas, target_train_labels, target_test_datas, target_test_labels, columns


def train_all(paths, out_path, num_repeat=50):

    mean_results = collections.defaultdict(list)
    all_results = collections.defaultdict(list)
    # 定义表格的列值
    columns = ["Precision", "Recall", "F_2", "MCC", "auc", "EA_Precision", "EA_Recall", "EA_F2", "P_opt"]

    # 加载数据
    for test_path in os.listdir(paths):
        test_name = os.path.split(test_path)[-1].replace(".xlsx", "")
        for train_path in os.listdir(paths):
            if train_path != test_path:
                train_name = os.path.split(train_path)[-1].replace(".xlsx", "")
                complete_train_path = os.path.join(paths, train_path)
                complete_test_path = os.path.join(paths, test_path)

                # return complete_train_path, complete_test_path

                print('source: ' + train_name + ': target ' + test_name + '***********************')

                total_inditator_data = train_model(complete_train_path, complete_test_path, num_repeat)
                for method in list(total_inditator_data.keys()):
                    inditator_data = total_inditator_data[method]
                    # 分别获取字典的key值和value值
                    dict_columns = list(inditator_data.keys())

                    new_columns = [dict_columns.index(col) for col in columns]
                    inditator_values = np.array(list(inditator_data.values()))[new_columns, :]

                    all_row = [train_name, test_name] + inditator_values.tolist()
                    # print("all row shape", inditator_values.shape)
                    all_results[method].append(all_row)

                    # 对所有指标值求平均值
                    mean_value = inditator_values.transpose()
                    mean_value = mean_value.mean(axis=0)

                    mean_row = [train_name, test_name] + mean_value.tolist()
                    mean_results[method].append(mean_row)

    # 保存指标平均值的结果
    for classify in list(mean_results.keys()):
        print("Now is print", classify, "mean model")
        one_data = mean_results[classify]

        one_data = pd.DataFrame(one_data, columns=["source data", "target data"] + columns)
        final_path = os.path.join(out_path, "mean_" + classify + ".xlsx")
        one_data.to_excel(final_path, index=False)

    # 保存指标的所有结果
    for classify in list(all_results.keys()):
        print("Now is print", classify, "all model")
        one_data = all_results[classify]
        one_data = pd.DataFrame(one_data, columns=["source data", "target data"] + columns)
        final_path = os.path.join(out_path, "all_" + classify + ".xlsx")
        one_data.to_excel(final_path, index=False)


def train_model(complete_train_path, complete_test_path, num_repeat):

    all_model_inditators = collections.defaultdict(dict)

    for i in range(num_repeat):

        train_datas, train_labels, _, _, target_test_datas, target_test_labels, columns = read_data(
            complete_train_path, complete_test_path)
        columns = list(columns[:-1]) + ['bug']

        # data wrapper
        train = data_wrapper(train_datas, train_labels, complete_train_path, columns)
        test = data_wrapper(target_test_datas, target_test_labels, complete_test_path, columns, flag=True)

        # for method in codep, max_diversity, asci, max_voting, bagging_j48, average_voting:
        for method in [average_voting]:

            print('start   ' + method.__name__ + str(i) + '***********')

            method(train, test)

            print('end   ' + method.__name__ + str(i) + '***********')

            test_df = get_loc_data(target_test_datas, target_test_labels, columns)
            test_df["pred"] = test.Yp

            # OLD
            old_inditators = get_metrics(target_test_labels, test.Yp)
            # 根据预测结果，可计算ROC曲线下的区域
            auc = roc_auc_score(y_true=target_test_labels, y_score=test.Yp)
            old_inditators["auc"] = auc

            # EA
            XYLuYp_sorted = test_df.sort_values('loc')
            ea_indicators = effort_aware(XYLuYp_sorted, positive_first(XYLuYp_sorted))

            # 合并两个指标值字典
            new_inditators = dict(old_inditators, **ea_indicators)

            for key in new_inditators:
                if key in all_model_inditators[method.__name__].keys():
                    all_model_inditators[method.__name__][key].append(new_inditators[key])
                else:
                    all_model_inditators[method.__name__][key] = [new_inditators[key]]

    return all_model_inditators


if __name__ == '__main__':
    # with JVM(packages=True) as weka:
    #     # datasets = map(prepare_dataset, sys.argv[1:])
    #     datasets = map(prepare_dataset, list(['Pageturner.xlsx', 'reddit.xlsx']))
    #     # print(list(datasets))
    #     for train, test in permutations(datasets, 2):
    #         for method in codep, max_diversity, asci, max_voting, bagging_j48:
    #             print('\n', train.path, test.path)
    #             method(train, test)
    #             metrics = evaluate(test.Yu, test.Yp, train.path, test.path)
    #             save(metrics, method.__name__ + '.csv')

    with JVM(packages=True) as weka:
        # complete_train_path, complete_test_path = generate_data('datas/comparison')
        # train_model(complete_train_path, complete_test_path)
        train_all('datas/New_Dataset', 'datas/comparison', num_repeat=25)
