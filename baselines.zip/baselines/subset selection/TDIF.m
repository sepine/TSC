function [x_train,y_train] = TDIF(x_train,y_train,x_test)
%ѵ������ʵ������ ���Ͼ��롣

[ns,m]=size(x_train);
nt=size(x_test,1);
%ѵ�������ڲ�����
n=ns;
i=1;
while(i<=n)
    x=x_train(i,:);
    y=x_train;
    y(i,:)=[];
    x=repmat(x,n-1,1);
    sigma = cov(y);
    dist = sum((x - y) * inv(sigma).*(x - y),2);
    dist_m = mean(dist);
    for j=n-1:-1:1
        a=j;
        if(dist(j)>=3*dist_m)
            if(j<=i-1)
                x_train(j,:)=[];
                y_train(j)=[];
            else
                x_train(j+1,:)=[];
                y_train(j+1)=[];
            end
            n=n-1;
        end
    end
    i=i+1;
end

%�ò������ݶ�ѵ�����ݹ���
n=nt;
i=1;
while(i<=n)
    y=x_train;
    ns=size(x_train,1);
    x=repmat(x_test(i,:),ns,1);
    sigma = cov(y);
    dist = sum((x - y) * inv(sigma).*(x - y),2);
    dist_m = mean(dist);
    for j=ns:-1:1
        if(dist(j)>=3*dist_m)
            x_train(j,:)=[];
            y_train(j)=[];
        end
    end
    i=i+1;
end