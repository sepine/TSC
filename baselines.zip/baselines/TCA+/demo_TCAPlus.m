clc
clear
addpath('.\liblinear\');
addpath('.\data\SOFTLAB\');
addpath('.\data\NASA\');
addpath('.\data\AEEEM\');
addpath('.\data\RELINK\');
%% Choose domains from Office+Caltech
%%% 'Caltech10', 'amazon', 'webcam', 'dslr' 
% src = 'Caltech10';
% tgt = 'amazon';
% 
% %% Load data
% load(['data/' src '_SURF_L10.mat']);     % source domain
% fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
% Xs = zscore(fts,1);    clear fts
% Ys = labels;           clear labels
% 
% load(['data/' tgt '_SURF_L10.mat']);     % target domain
% fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
% Xt = zscore(fts,1);     clear fts
% Yt = labels;            clear labels

data1 = xlsread('EQ.xlsx');
data2 = xlsread('JDT.xlsx');
data3 = xlsread('LC.xlsx');
data4 = xlsread('ML.xlsx');
data5 = xlsread('PDE.xlsx');
% data1 = xlsread('ar1.xlsx');
% data2 = xlsread('ar3.xlsx');
% data3 = xlsread('ar4.xlsx');
% data4 = xlsread('ar5.xlsx');
% data5 = xlsread('ar6.xlsx');
% data1 = xlsread('CM1.xlsx');
% data2 = xlsread('MW1.xlsx');
% data3 = xlsread('PC1.xlsx');
% data4 = xlsread('PC3.xlsx');
% data5 = xlsread('PC4.xlsx');
% data1 = xlsread('RELINK\A.xlsx');
% data2 = xlsread('RELINK\S.xlsx');
% data3 = xlsread('RELINK\Z.xlsx');

data = cell(1,5); % ע���޸�
data{1,1} = data1;
data{1,2} = data2;
data{1,3} = data3;
data{1,4} = data4;
data{1,5} = data5;

ttt = 0;
Performance = [];
for i = 1:5
    for j = 1:5
        i
        j
        if i~=j
            target = [];
            source = [];
            sourcedata = [];
            targetdata = [];
            target = cell2mat(data(1,i));
            source = cell2mat(data(1,j));
            LOC = target(:,1);
            [sourcedata, targetdata] = DataPreprocess(source, target);
            sourcedata(isnan(sourcedata))=0;
            targetdata(isnan(targetdata))=0;
            Performance(1 + ttt * 1, :) = calculate(sourcedata, targetdata, LOC); 
            ttt = ttt+1;
        end
    end
end
xlswrite('TTTTT.xlsx',Performance);