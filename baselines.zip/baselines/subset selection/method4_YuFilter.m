function performance3 = method4_YuFilter(source, target, loc) %ѡ������

XX_data = source;
YY_data = target;
X = XX_data(:,1:end-1);
Y = YY_data(:,1:end-1);
X_num = size(XX_data,1);
Y_num = size(YY_data,1);
all_data1 = [XX_data;YY_data];
all_data = all_data1(:,1:end-1);

cluster_num = round((X_num+Y_num)/10);

index4 = clusterdata(all_data,'linkage', 'average', 'maxclust', cluster_num);

ix_3 = [];
count = 0;
for i = 1:X_num
      if (~isempty(find(index4(X_num+1:size(index4,1))==index4(i))))
        count = count+1;
        ix_3(count) = i;
    end
end

L31 = length(ix_3);
prior_train_method3 = XX_data(ix_3,:);
L32 = length(find(prior_train_method3(:,end)==1));

% performance3 = WELM(prior_train_method3, YY_data, loc);
performance3 = LR(prior_train_method3, YY_data, loc);

PP = [L31 L32 performance3];
