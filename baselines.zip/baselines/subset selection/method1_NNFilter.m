function performance1 = method1_NNFilter(source, target, loc)

XX_data = source;
YY_data = target;

X = XX_data(:,1:end-1);
Y = YY_data(:,1:end-1);

%method_1 %����ڸ���ȡ10
D = zeros(size(X,1),size(Y,1));
K1 = 10;
for i = 1:size(X,1)
        for j = 1:size(Y,1)
            D(i,j) = norm(X(i,:)-Y(j,:))^2;
        end
 end
[s,ix_1] = sort(D,1);
ix_1 = ix_1(1:K1,:);
ix_1 = unique(ix_1);
L11 = length(ix_1);

%��ѡ���ѵ������
prior_train_method1 = XX_data(ix_1,:);
L12 = length(find(prior_train_method1(:,end)==1));
performance1 = LR(prior_train_method1,YY_data,loc);

% performance1 = WELM(prior_train_method1, YY_data,loc);
PP = [L11 L12 performance1];