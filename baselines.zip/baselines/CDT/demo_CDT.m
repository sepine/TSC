clc
clear
addpath('.\liblinear\');
addpath('.\data\SOFTLAB\');
addpath('.\data\NASA\');
addpath('.\data\AEEEM\');
addpath('.\data\RELINK\');
%% Choose domains from Office+Caltech
%%% 'Caltech10', 'amazon', 'webcam', 'dslr' 
% src = 'Caltech10';
% tgt = 'amazon';
% 
% %% Load data
% load(['data/' src '_SURF_L10.mat']);     % source domain
% fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
% Xs = zscore(fts,1);    clear fts
% Ys = labels;           clear labels
% 
% load(['data/' tgt '_SURF_L10.mat']);     % target domain
% fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
% Xt = zscore(fts,1);     clear fts
% Yt = labels;            clear labels

% data1 = xlsread('EQ.xlsx');
% data2 = xlsread('JDT.xlsx');
% data3 = xlsread('LC.xlsx');
% data4 = xlsread('ML.xlsx');
% data5 = xlsread('PDE.xlsx');

% data1 = xlsread('ar1.xlsx');
% data2 = xlsread('ar3.xlsx');
% data3 = xlsread('ar4.xlsx');
% data4 = xlsread('ar5.xlsx');
% data5 = xlsread('ar6.xlsx');

% data1 = xlsread('CM1.xlsx');
% data2 = xlsread('MW1.xlsx');
% data3 = xlsread('PC1.xlsx');
% data4 = xlsread('PC3.xlsx');
% data5 = xlsread('PC4.xlsx');

data1 = xlsread('RELINK\A.xlsx');
data2 = xlsread('RELINK\S.xlsx');
data3 = xlsread('RELINK\Z.xlsx');

data = cell(1,3); % ע���޸�
data{1,1} = data1;
data{1,2} = data2;
data{1,3} = data3;
% data{1,4} = data4;
% data{1,5} = data5;

ttt = 0;
Performance = [];
for i = 1:3
    for j = 1:3
        i
        j
        if i~=j
            target = [];
            source = [];
            target = cell2mat(data(1,i));
            source = cell2mat(data(1,j));
%             Performance(1 + ttt * 13 : 13 + ttt * 13,:) = calculate(source, target);
            Performance(1 + ttt * 1, :) = calculate(source, target); 
            ttt = ttt+1;
        end
    end
end
size(Performance)
xlswrite('TTTTT.xlsx',Performance);



% source = xlsread('C:\Users\XuZhou\Desktop\WBDA\data\NASA\PC3.xlsx');
% Xs = source(:,1:end-1);
% Xs = zscore(Xs,1);
% Ys = source(:,end);
% 
% target = xlsread('C:\Users\XuZhou\Desktop\WBDA\data\NASA\CM1.xlsx');
% Xt = target(:,1:end-1);
% LOC = target(:,1);%��Ҫ�޸İ�1,11
% Xt = zscore(Xt,1);
% Yt = target(:,end);
% 
% % calculate gamma
% 
% % all_data = [source(:,1:end-1);target(:,1:end-1)];
% all_data = [Xs;Xt];
% gamma_value = mean(pdist(all_data));
% 
% [~, performance_ori] = LR(Xs,Ys,Xt,Yt,LOC);
% 
% %% Set algorithm options
% options.gamma = 1.0;
% options.lambda = 0.01;
% options.kernel_type = 'linear';
% options.T = 10;
% options.dim = ceil(0.15 * size(Xs,2));
% % options.mu = 0.9;
% options.mode = 'BDA';
% %% Run algorithm
% tt =1;
% for mu = 0:0.1:1
%     mu
%     [Performance11(tt,:), Performance12(tt,:)] = MyBDA(Xs,Ys,Xt,Yt,options,mu,LOC);
%     tt = tt+1;
% end
% Performance = [
%     performance_ori performance_ori
%     Performance11 Performance12];
% xlswrite('Performance.xlsx',Performance);