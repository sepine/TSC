function performance3 = method3_KawataFilter(source, target, loc)

XX_data = source;
YY_data = target;
X = XX_data(:,1:end-1);
Y = YY_data(:,1:end-1);
X_num = size(XX_data,1);
Y_num = size(YY_data,1);
all_data1 = [XX_data;YY_data];
all_data = all_data1(:,1:end-1);

epsilon = 1;
MinPts = 10;
[index, isnoise] = DBSCAN(all_data,epsilon,MinPts);

%�м������ж�Ϊ���������дر��
 for tt = 1:size(index,1)
     if(index(tt) ~= 0 & isnoise(tt) == 1)
         index(tt) = 0;
     end
 end

% yy = 0;
%  for ttt = 1:size(index,1)
%      if(index(ttt) ~= 0 & isnoise(ttt) == 1)
%          yy = yy+1;
%          ttt
%      end
%  end
% yy

ix_3 = [];
count = 0;
for i = 1:X_num
    if(index(i)~=0)
      if (~isempty(find(index(X_num+1:size(index,1))==index(i))))
        count = count+1;
        ix_3(count) = i;
      end
    end
end
ix_3
L31 = length(ix_3);
prior_train_method3 = XX_data(ix_3,:);
L32 = length(find(prior_train_method3(:,end)==1));
if L32 == 0
    performance3 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
else
    performance3 = LR(prior_train_method3, YY_data, loc);
end

PP = [L31 L32 performance3];
