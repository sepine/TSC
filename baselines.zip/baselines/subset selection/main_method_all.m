clc
clear
addpath('.\liblinear\');
addpath('.\data\SOFTLAB\');
addpath('.\data\NASA\');
addpath('.\data\AEEEM\');
addpath('.\data\RELINK\');
%% Choose domains from Office+Caltech
%%% 'Caltech10', 'amazon', 'webcam', 'dslr' 
% src = 'Caltech10';
% tgt = 'amazon';

data1 = xlsread('CM1.xlsx');
data2 = xlsread('MW1.xlsx');
data3 = xlsread('PC1.xlsx');
data4 = xlsread('PC3.xlsx');
data5 = xlsread('PC4.xlsx');
% data1 = xlsread('EQ.xlsx');
% data2 = xlsread('JDT.xlsx');
% data3 = xlsread('LC.xlsx');
% data4 = xlsread('ML.xlsx');
% data5 = xlsread('PDE.xlsx');
% data1 = xlsread('ar1.xlsx');
% data2 = xlsread('ar3.xlsx');
% data3 = xlsread('ar4.xlsx');
% data4 = xlsread('ar5.xlsx');
% data5 = xlsread('ar6.xlsx');
% data1 = xlsread('RELINK\A.xlsx');
% data2 = xlsread('RELINK\S.xlsx');
% data3 = xlsread('RELINK\Z.xlsx');

data = cell(1,5); % ע���޸�
data{1,1} = data1;
data{1,2} = data2;
data{1,3} = data3;
data{1,4} = data4;
data{1,5} = data5;

ttt = 0;
Performance = [];
for i = 1:5
    for j = 1:5
        i
        j
        if i~=j
            target = [];
            source = [];
            target1 = cell2mat(data(1,i));
            source1 = cell2mat(data(1,j));
            loc = target1(:,1);
            
            source_f1 = source1(:,1:end-1);
            source_l = source1(:,end);
            source_f = zscore(source_f1,1);
            source = [source_f source_l];
            
            target_f1 = target1(:,1:end-1);
            target_l = target1(:,end);
            target_f = zscore(target_f1,1);
            target = [target_f target_l];
            
            Performance(1 + ttt * 1, :) = LR(source, target, loc); 
            ttt = ttt+1;
        end
    end
end
size(Performance)
xlswrite('TTTTT.xlsx',Performance);

