function mean_performance2 = method2_PeterFilter(source, target, loc)
%��ԭʼ��Peter Filter,�ȸ���ԭ��Ŀģ��ѡ���ܻ�ӭ��Ŀ��ģ�飬Ȼ���ÿһ�����ܻ�ӭģ��ѡ���������fan.

XX_data = source;
YY_data = target;
X = XX_data(:,1:end-1);
Y = YY_data(:,1:end-1);
X_num = size(XX_data,1);
Y_num = size(YY_data,1);
all_data1 = [XX_data;YY_data];
all_data = all_data1(:,1:end-1);


cluster_num = round((X_num+Y_num)/10);
Z = Y;

for tt = 1:1:30
    Y = Z;
    idx = kmeans(all_data,cluster_num);
    index_x = idx(1:X_num);
    index_y = idx(1+X_num:X_num+Y_num);
    iy_2=[];
    count1 = 0;
    for i = 1:X_num
        cluster1 = idx(i);
        y_index = find(idx(1+X_num:X_num+Y_num)==cluster1);
        min_index1 = 0;
        min_distance1 = inf;
        if (~isempty(y_index))
            count1 = count1+1;
            for dex1 = 1:size(y_index,1)
               j = y_index(dex1);
               distance1 = norm(Y(j,:)-X(i,:))^2;
               if (distance1<min_distance1)
                  min_distance1 = distance1;
                  min_index1 = j;
               end
            end
           iy_2(count1)=min_index1;
        end
    end

    iy_2 = unique(iy_2);

    clear idx

    index_y_popolar = index_y(iy_2);
    Y = Y(iy_2,:);

    idx2 = [index_x; index_y_popolar];
    ix_2=[];
    count = 0;
    for i = 1:size(Y,1)
        cluster = idx2(i+X_num);
        x_index = find(idx2(1:X_num)==cluster);
        min_index = 0;
        min_distance = inf;
        if (~isempty(x_index))
            count = count+1;
            for dex = 1:size(x_index,1)
               j = x_index(dex);
               distance = norm(X(j,:)-Y(i,:))^2;
               if (distance<min_distance)
                  min_distance = distance;
                  min_index = j;
               end
            end
           ix_2(count)=min_index;
        end
    end
    ix_2 = unique(ix_2);

    L21_1(tt) = length(ix_2); %ѡ��������ĸ���
    prior_train_method2 = XX_data(ix_2,:);
    L22_1(tt) = length(find(prior_train_method2(:,end)==1));%ѡ�����ȱ�ݵ������ĸ���
%     performance2_1(tt,:) = WELM(prior_train_method2, YY_data, loc);
    
    performance2_1(tt,:) = LR(prior_train_method2, YY_data, loc);

end

performance2 = performance2_1;


mean_performance2 = nanmean(performance2,1);
mean_L21 = nanmean(L21_1);
mean_L22 = nanmean(L22_1);

PP = [mean_L21 mean_L22 mean_performance2];