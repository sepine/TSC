function performance5 = method5_HISNN(source, target, loc) %ѡ������

[a,b]=size(source);
[c,d]=size(source);
x_train=source(:,1:(b-1));
y_train=source(:,b);
x_test=target(:,1:(d-1));
y_test=target(:,d); 

%ѵ������ʵ������
[xa,ya] = TDIF(x_train,y_train,x_test);
[xb,yb] = MDH(x_train,y_train,x_test);
%�ϲ�
train_filter = [xa ya;xb yb];
train_filter = unique(train_filter,'rows');
x_train = train_filter(:,1:end-1);
y_train = train_filter(:,end); %label

size(train_filter)


% % % % % % % % a=size(xa,1);
% % % % % % % % b=size(xb,1);
% % % % % % % % m=1;
% % % % % % % % for i=1:a
% % % % % % % %     meature=0;
% % % % % % % %     for j=1:b
% % % % % % % %         if(all(xa(i,:)==xb(j,:)))
% % % % % % % %             meature=1;
% % % % % % % %             break;
% % % % % % % %         end
% % % % % % % %     end
% % % % % % % %     if(meature==0)
% % % % % % % %         xb(b+m,:)=xa(i,:);
% % % % % % % %         yb(b+m)=ya(i);
% % % % % % % %         m=m+1;
% % % % % % % %     end
% % % % % % % % end
% % % % % % % % %ѵ������
% % % % % % % % x_train = xb;
% % % % % % % % y_train = yb';

%���ر�Ҷ˹������
%native=fitcnb(x_train,y_train);

%�߼��ع�ģ��
GM = fitglm(x_train,y_train,'Distribution','binomial');

%��������ʵ��ѡ��
label = TDIS(x_train,y_train,x_test,GM);

performance5 = HISNN_indicator(y_test, label, loc)


        



