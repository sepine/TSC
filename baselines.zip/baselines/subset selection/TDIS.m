function label = TDIS(x_train,y_train,x_test,native)
%testing data instance selection
  
[ns,m]=size(x_train);
nt=size(x_test,1);
label=zeros(1,nt)-1;


for i=1:nt
    D = pdist2(x_test(i,:),x_train, 'hamming');
    Hmin=min(D);
    num=0;
    la=-1;
    id=0;
    for j=1:ns
        if(D(j)==Hmin)
            num=num+1;
        end
        if num==1
            la=y_train(j);
            id=j;
        elseif num>1&&la~=y_train(j)  %case3
            %���ñ�Ҷ˹
            label(i)=native.predict(x_test(i,:));
            break;
        end
    end
    if label(i)==-1&&num>1 %case2
        label(i)=la;
    elseif label(i)==-1&&num==1 %case1
        xs=x_train(id,:);
        xt=x_train;
        yt=y_train;
        xt(id,:)=[];
        yt(id)=[];
        D = pdist2(xs,xt, 'hamming');
        Hmin=min(D);
        num=0;
        for j=1:ns-1
            if(D(j)==Hmin)
                num=num+1;
            end
            if num==1
                la=yt(j);
            elseif num>1&&la~=yt(j)  %case1-3
                %���ñ�Ҷ˹
                label(i)=native.predict(x_test(i,:));
                break;
            end
        end
        if label(i)==-1&&num==1 %case 1-1
            %���ñ�Ҷ˹
            label(i)=native.predict(x_test(i,:));
        elseif label(i)==-1&&num>1 %case 1-2
            label(i)=la;
        end
    end
        
end