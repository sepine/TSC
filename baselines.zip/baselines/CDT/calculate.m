function performance = calculate(source, target)

% source = xlsread('C:\Users\XuZhou\Desktop\WBDA\data\NASA\PC3.xlsx');
Xs = source(:,1:end-1);
Xs = zscore(Xs,1);
Ys = source(:,end);

% target = xlsread('C:\Users\XuZhou\Desktop\WBDA\data\NASA\CM1.xlsx');
Xt = target(:,1:end-1);
LOC = target(:,1);%��Ҫ�޸�:AEEEM 26; SOFTLAB 1; RELINK 11; NASA 37
Xt = zscore(Xt,1);
Yt = target(:,end);

% calculate gamma

% all_data = [source(:,1:end-1);target(:,1:end-1)];
% all_data = [Xs;Xt];
% gamma_value = mean(pdist(all_data));

[~, performance_ori] = LR(Xs,Ys,Xt,Yt,LOC);

%% Set algorithm options
options.gamma = 1.0;
options.lambda = 0.1;
options.kernel_type = 'linear';
options.T = 5; % ����1��
options.dim = ceil(0.05 * size(Xs,2));
% options.mu = 0;  % represent TCA
mu = 1; % represent TCA
options.mode = 'BDA';
%% Run algorithm
performance = MyBDA(Xs,Ys,Xt,Yt,options,mu,LOC);

% Performance = [
%     performance_ori
%     Performance11
%     zeros(1,16)];