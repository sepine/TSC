function [Preprocesssource, Preprocesstarget] = DataPreprocess(source, target)

sourcedata=source(:,1:end-1);
sourcelabel=source(:,end);
targetdata=target(:,1:end-1);
targetlabel= target(:,end);

[ns,ms]=size(sourcedata);
[nt,mt]=size(targetdata); % ms-1=mt

%����ŷʽ����DIST
sourceDIST= pdist(sourcedata,'euclidean');
targetDIST=pdist(targetdata,'euclidean');

%����DCV
sourceDCV=zeros(1,6);
targetDCV=zeros(1,6);

sourceDCV(1)=min(sourceDIST);
targetDCV(1)=min(targetDIST);

sourceDCV(2)=max(sourceDIST);
targetDCV(2)=max(targetDIST);

sourceDCV(3)=mean(sourceDIST);
targetDCV(3)=mean(targetDIST);

sourceDCV(4)=median(sourceDIST);
targetDCV(4)=median(targetDIST);

sourceDCV(5)=std(sourceDIST);
targetDCV(5)=std(targetDIST);

sourceDCV(6)=ns;
targetDCV(6)=nt;

%ȷ���ȼ�
degree=zeros(1,6);
for i=1:6
        if(sourceDCV(i)*1.6<targetDCV(i)) %MUCH MORE
            degree(i)=1;
        elseif(sourceDCV(i)*1.3<targetDCV(i)) %MORE
            degree(i)=2;
        elseif(sourceDCV(i)*1.1<targetDCV(i)) %SLIGHTLY MORE
            degree(i)=3;
        elseif(sourceDCV(i)*0.9<targetDCV(i)) %SAME
            degree(i)=4;
        elseif(sourceDCV(i)*0.7<targetDCV(i))%SLIGHTLY LESS
            degree(i)=5;
        elseif(sourceDCV(i)*0.4<targetDCV(i))%LESS
            degree(i)=6;
        else degree(i)=7; %MUCH LESS
        end
end

con=-1;
%rule1
if((degree(3)==4)&&(degree(5)==4))
    fprintf('NoN\n');
    con=0;
end
%rule2
% if((degree(6)==1 || degree(6)==7) && (degree(1)==1 || degree(1)==7) && (degree(2)==1 || degree(2)==7))
if((degree(6)==1 && degree(1)==1 &&  degree(2)==1) || (degree(6)==7 && degree(1)==7 && degree(2)==7))
    fprintf('N1\n');
    con=1;
end
%rule3
if((degree(5)==1&&degree(6)>4) || (degree(5)==7&&degree(6)<4))
    fprintf('N3\n');
    con=3;
end
%rule4
if((degree(5)==1&&degree(6)<4) || (degree(5)==7&&degree(6)>4))
    fprintf('N4\n');
    con=4;
end
%rule5
if(con==-1)
    fprintf('N2\n');
    con=2;
end

Preprocesssource = [sourcedata sourcelabel];
Preprocesstarget = [targetdata targetlabel];

if(con==1)   %��Ӧ����N1
    maxS=zeros(1,ms-1);
    minS=zeros(1,ms-1);
    maxT=zeros(1,mt);
    minT=zeros(1,mt);
    for i=1:(ms-1)
        maxS(i)=max(sourcedata(:,i));
        minS(i)=min(sourcedata(:,i));
    end
    for i=1:ns
        for j=1:ms-1
            sourcedata(i,j)=(sourcedata(i,j)-minS(j))./(maxS(j)-minS(j));
        end
    end
    for i=1:mt
        maxT(i)=max(targetdata(:,i));
        minT(i)=min(targetdata(:,i));
    end
    for i=1:nt
        for j=1:mt
            targetdata(i,j)=(targetdata(i,j)-minT(j))./(maxT(j)-minT(j));
        end
    end
    
    Preprocesssource = [sourcedata sourcelabel];
    Preprocesstarget = [targetdata targetlabel];
    return
    
elseif(con==2)  %N2
    stdS=zeros(1,ms-1);
    meanS=zeros(1,ms-1);
    stdT=zeros(1,mt);
    meanT=zeros(1,mt);
    for i=1:ms-1
        stdS(i)=std(sourcedata(:,i));
        meanS(i)=mean(sourcedata(:,i));
    end
    for i=1:ns
        for j=1:ms-1
            sourcedata(i,j)=(sourcedata(i,j)-meanS(j))./stdS(j);
        end
    end
    for i=1:mt
        stdT(i)=std(targetdata(:,i));
        meanT(i)=mean(targetdata(:,i));
    end
    for i=1:nt
        for j=1:mt
            targetdata(i,j)=(targetdata(i,j)-meanT(j))./stdT(j);
        end
    end
    
    Preprocesssource = [sourcedata sourcelabel];
    Preprocesstarget = [targetdata targetlabel];
    return
    
elseif(con==3) %N3
    stdS=zeros(1,ms-1);
    meanS=zeros(1,ms-1);
    for i=1:ms-1
        stdS(i)=std(sourcedata(:,i));
        meanS(i)=mean(sourcedata(:,i));
    end
    for i=1:ns
        for j=1:ms-1
            sourcedata(i,j)=(sourcedata(i,j)-meanS(j))./stdS(j);
        end
    end
    for i=1:nt
        for j=1:ms-1
            targetdata(i,j)=(targetdata(i,j)-meanS(j))./stdS(j);
        end
    end
    
    Preprocesssource = [sourcedata sourcelabel];
    Preprocesstarget = [targetdata targetlabel];
    return
    
elseif(con==4) % N4

    stdT=zeros(1,mt);
    meanT=zeros(1,mt);
    for i=1:mt
        stdT(i)=std(targetdata(:,i));
        meanT(i)=mean(targetdata(:,i));
    end
    for i=1:nt
        for j=1:mt
            targetdata(i,j)=(targetdata(i,j)-meanT(j))./stdT(j);
        end
    end
    for i=1:ns
        for j=1:mt
            sourcedata(i,j)=(sourcedata(i,j)-meanT(j))./stdT(j);
        end
    end

    Preprocesssource = [sourcedata sourcelabel];
    Preprocesstarget = [targetdata targetlabel];
    return  
end




% %������򻯺�����
% fprintf('ԭ���ݼ�\n');
% disp(sourcedata);
% fprintf('\n');
% fprintf('Ŀ�����ݼ�\n');
% disp(targetdata);
% fprintf('\n');
